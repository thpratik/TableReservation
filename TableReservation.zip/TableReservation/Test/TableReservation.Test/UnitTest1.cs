﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TableReservation.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
