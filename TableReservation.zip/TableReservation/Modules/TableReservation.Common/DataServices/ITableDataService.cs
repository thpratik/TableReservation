﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TableReservation.Common.DataServices
{
    public interface ITableDataService : IDataService
    {
    }
}
