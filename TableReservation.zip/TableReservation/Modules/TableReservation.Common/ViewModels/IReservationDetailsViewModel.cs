﻿
namespace TableReservation.Common.ViewModel
{
    public interface IReservationDetailsViewModel
    {
    }
}
