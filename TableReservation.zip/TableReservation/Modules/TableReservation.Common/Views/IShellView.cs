﻿using TableReservation.Common.ViewModel;

namespace TableReservation.Common.View
{
    public interface IShellView
    {
        IShellViewModel ViewModel { get; }
    }
}
