﻿using TableReservation.Common.ViewModel;

namespace TableReservation.Common.View
{
    public interface IReservationDashBoardView
    {
        IReservationDashBoardViewModel ViewModel { get; }
    }
}
