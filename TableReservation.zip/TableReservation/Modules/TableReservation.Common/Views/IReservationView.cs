﻿using TableReservation.Common.ViewModel;

namespace TableReservation.Common.View
{
    public interface IReservationView
    {
        IReservationViewModel ViewModel { get; }
    }
}
