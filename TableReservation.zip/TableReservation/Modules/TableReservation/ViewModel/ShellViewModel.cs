﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TableReservation.Common.Base.ViewModel;
using TableReservation.Common.ViewModel;

namespace TableReservation.ViewModel
{
    public class ShellViewModel : ViewModelBase, IShellViewModel
    {
        public ShellViewModel()
        {
        }
    }
}
