﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TableReservation
{
    public static class RegionNames
    {
        public const string ShellViewRegion = "ShellViewRegion";
        public const string ReservationDetailsRegion = "ReservationDetailsRegion";
        public const string ReservationDashboardRegion = "ReservationDashboardRegion";
    }
}
